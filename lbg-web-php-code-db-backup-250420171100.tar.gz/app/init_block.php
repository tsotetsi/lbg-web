<?php
/* Author : Tsotets Thapelo
 * Initialize project database
 * Contact : me@tsotetesithapelo.co.za
 * Copyright : GNU GPL*/

	// include_once 'db.php';

	// $blocked_table = "blocked";

	// $pdo = new PDO("pgsql:host=localhost;port=5432;dbname=lbgsample;user=webdev;password=webdev");
	// $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	// $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

	// try{

	// 		// $query = "CREATE TABLE IF NOT EXISTS $blocked_table(
	// 		// 			id SERIAL PRIMARY KEY,
	// 		// 			student_number VARCHAR(32),
	// 		// 			blocked_date TIMESTAMP NOT NULL
	// 		// 		);";
	// 		// $stmt = $pdo->prepare($query);
	// 		// $stmt->execute();
		
	// } catch (Exception $ex) {
	// 	echo "Error creating ".$blocked_table;
	// 	echo $ex->getMessage();
	// }


?>