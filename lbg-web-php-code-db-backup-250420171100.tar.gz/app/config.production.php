<?php
/* Author : Tsotets Thapelo
 * Contact : me@tsotetesithapelo.co.za
 * Copyright : GNU GPL*/

    return array(
        'hostname' => '154.127.59.170',
        'port' => '5432',
        'db_username' => 'myres',
        'db_password' => '57dse0IfU2@nd_=enx2(ndf{J%!3',
        'db_name' => 'db_myres_lbg_2017_live',
        'db_type' => 'postgresql',
        );
?>